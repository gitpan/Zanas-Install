################################################################################

sub select_pub_page {

	redirect ('/about/') if $_REQUEST {__uri} eq '/';
	
	my $page = {};
	
	($page -> {id}, $page -> {id_rubric}) = sql_select_array ('SELECT id, id_rubric FROM articles WHERE full_path = ?', $_REQUEST {__uri_chomped});
	$page -> {id_rubric} ||= sql_select_scalar ('SELECT id FROM rubrics WHERE full_path = ?', $_REQUEST {__uri_chomped});	

	if (!$page -> {id_rubric} && $_REQUEST {__uri} !~ m{/$}) {		
		my $rubric_uri = $_REQUEST {__uri};
		$rubric_uri =~ s{/[^/]*$}{};
		$page -> {id_rubric} ||= sql_select_scalar ('SELECT id FROM rubrics WHERE full_path = ?', $rubric_uri);	
	}

	redirect ('/sitemap/') unless $page -> {id_rubric} > 0;
	
	$page -> {path} = sql_select_path ('rubrics', $page -> {id_rubric}, {name => label});
	
	$page -> {title} = $page -> {path} -> [-1] -> {name};
		
	$page -> {type} =
		$_REQUEST {__uri_chomped} eq '/sitemap' ? 'pub_sitemap' :
		$_REQUEST {__uri_chomped} eq '/search'  ? 'pub_search'  :
		$_REQUEST {__uri_chomped} eq '/info/privileges' ? 'pub_info_privileges' :
		$_REQUEST {__uri_chomped} eq '/info/privileges/by_cathegory' ? 'pub_info_privileges_by_cathegory' :
		'pub_content';
		
	$page -> {id} ||= $_REQUEST {id};

	$page -> {main_menu} = sql_select_all  ("SELECT id, label, full_path FROM rubrics WHERE parent = 0 AND product_is_visible = 1 AND ord < 100 ORDER BY ord");
	map {$_ -> {active} = $_ -> {id} == $page -> {path} -> [0] -> {id} ? 'A' : ''} @{$page -> {main_menu}};
	
	$page -> {high_menu} = sql_select_all  ("SELECT id, label, full_path FROM rubrics WHERE parent = 0 AND product_is_visible = 1 AND ord >= 100 ORDER BY ord");
	
	return $page;	
	
}

1;
