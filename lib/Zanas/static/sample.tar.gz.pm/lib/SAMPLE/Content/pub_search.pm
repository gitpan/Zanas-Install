################################################################################

sub select_pub_search {
	
	$_REQUEST {q} or return {};
	
	$_REQUEST {opt} eq 'and' or $_REQUEST {opt} eq 'or' or $_REQUEST {opt} = 'and';
	
	my $q = $_REQUEST {q};
	
	$q =~ y{*}{%};
	
	my $glue = " $_REQUEST{opt} ";

	my $ftx_filter = join $glue, map {" body LIKE '%$_%'"} split /[^A-Za-z�-��-�0-9\%]+/, $q;

#	my $start = $_REQUEST {start} + 0;

#	my ($pub_search, $cnt)= sql_select_all_cnt (<<EOS, $q);
	my $articles = sql_select_all (<<EOS);
		SELECT
			id
			, full_path
			, label
			, '' AS slash
		FROM
			articles
		WHERE
			fake = 0
			and ($ftx_filter)
		ORDER BY
			label
EOS

	my $rubrics = sql_select_all (<<EOS);
		SELECT
			id
			, full_path
			, label
			, '/' AS slash
		FROM
			rubrics
		WHERE
			fake = 0
			and ($ftx_filter)
		ORDER BY
			label
EOS

	return {
		pub_search => [@$rubrics, @$articles],
	};
}

1;
