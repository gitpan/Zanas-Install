################################################################################

sub _articles_mail_body {

	my ($item) = @_;

	return <<EOH;
<html>
<head>
	<BASE class=Base HREF="http://$ENV{HTTP_HOST}/">	
	<LINK href="http://$ENV{HTTP_HOST}/i/css/MSIE_5/Base-Basic.css" type=text/css rel=stylesheet>
	<LINK href="http://$ENV{HTTP_HOST}/i/css/MSIE_5/Common-Basic.css" type=text/css rel=stylesheet>
	<LINK href="http://$ENV{HTTP_HOST}/i/css/MSIE_5/Controls-Basic.css" type=text/css rel=stylesheet>
	<LINK href="http://$ENV{HTTP_HOST}/i/css/MSIE_5/Containers-Basic.css" type=text/css rel=stylesheet>
	<LINK href="http://$ENV{HTTP_HOST}/i/css/MSIE_5/Parts-Basic.css" type=text/css rel=stylesheet>
</head>
<body>
$$item{body}

<p><a href="$$item{full_path}">http://$ENV{HTTP_HOST}$$item{full_path}</a>
</body>
</html>
EOH

}



################################################################################

sub do_spam_test_articles {

	my $item = sql_select_hash ('articles');	
	sql_do ('UPDATE articles SET is_spam_tested = 1 WHERE id = ?', $_REQUEST {id});	

	async 'send_mail', ({
		to           => 'do@zanas.ru',
		subject      => $item -> {label},
		text         => _articles_mail_body ($item),
		content_type => 'text/html',
	});	
	
#	notify_mail ('do@zanas.ru', $to -> {label}, $item -> {label}, $item -> {body});	

}

################################################################################

sub do_spam_articles {

	my $item = sql_select_hash ('articles');

	my $tos = sql_select_all ('SELECT label, mail FROM external_users WHERE is_active = 1 AND is_subscribed = 1');

	send_mail ({
		to           => $tos,
		subject      => $item -> {label},
		text         => _articles_mail_body ($item),
		content_type => 'text/html',
	});	
	
#	foreach my $to (@$tos) {
#		notify_mail ($to -> {mail}, $to -> {label}, $item -> {label}, $item -> {body});
#	}
	
}

################################################################################

sub validate_update_articles {

	if ($_REQUEST {_name}) {
		my $parent = sql_select_scalar ('SELECT id_rubric FROM articles WHERE id = ?', $_REQUEST {id});
		return 'duplicated_name' if sql_select_scalar ('SELECT COUNT(*) FROM articles WHERE id_rubric = ? AND id <> ? AND fake = 0 AND name = ?', $parent, $_REQUEST {id}, $_REQUEST {_name});
	}

	return undef;
	
}

################################################################################

sub validate_delete_articles {

#	if (sql_select_scalar ('SELECT COUNT(*) FROM articles WHERE parent = ?', $_REQUEST {id})) {
#		return '������� ���� ������� ��� �������� ����������';
#	}
	
	return undef;
	
}

################################################################################

sub do_delete_articles {
		
	sql_select_loop ('SELECT id FROM images WHERE id_article = ?', sub {
	
		$_REQUEST {id} = $i -> {id};
			
		sql_do_delete ('images', {
			file_path_columns => ['path_photo'],
		});
		
	}, $_REQUEST {id});

#        my ($id_rubric, $parent) = sql_select_array ('SELECT id_rubric, parent FROM articles WHERE id = ?', $_REQUEST {id});
        my $id_rubric = sql_select_scalar ('SELECT id_rubric FROM articles WHERE id = ?', $_REQUEST {id});
	
	sql_do_delete ('articles');

	if ($parent) {
		$_REQUEST {id} = $parent;
	}
	else {
		$_REQUEST {parent} = $id_rubric;
		$_REQUEST {type} = 'rubrics';
		delete $_REQUEST {id};
	}
	
}

################################################################################

sub do_toggle_articles {

	sql_do ('UPDATE articles SET is_visible = 1 - IFNULL(is_visible, 0) WHERE id = ?', $_REQUEST {id});
			
	if ($_REQUEST {list}) {

#		my $parent = sql_select_scalar ('SELECT parent FROM articles WHERE id = ?', $_REQUEST {id});
#		if ($parent) {
#			$_REQUEST {id} = $parent;
#			return;
#		}

		$_REQUEST {parent} = sql_select_scalar ('SELECT id_rubric FROM articles WHERE id = ?', $_REQUEST {id});
		$_REQUEST {type} = 'rubrics';
		delete $_REQUEST {id};
	}	
		
}

################################################################################

sub do_update_articles {

	my $item = sql_select_hash ('articles');

	$_REQUEST {_dt} =~ s{(\d\d)\.(\d\d)\.(\d\d\d\d)}{$3-$2-$1};
	$_REQUEST {_is_spam_tested} = 0;
	sql_do_update ('articles', [qw(label ord announce body dt is_spam_tested)]);

	if ($_REQUEST {_name} && $_REQUEST {_name} ne $item -> {name}) {
#		$_REQUEST {_name} ||= $_REQUEST {id};
		$_REQUEST {_full_path} = join '/', (sql_select_scalar ('SELECT full_path FROM rubrics WHERE id = ?', $item -> {id_rubric}), $_REQUEST {_name});
		sql_do_update ('articles', [qw(name full_path)]);
	}	
					
}

################################################################################

sub get_item_of_articles {

	my $item = sql_select_hash ('articles');
	
	$_REQUEST {__read_only} ||= !($_REQUEST {__edit} || $item -> {fake});	
	
	$item -> {dt} =~ s{(\d\d\d\d)\-(\d\d)\-(\d\d)}{$3.$2.$1};
	
	$item -> {rubric_path} = sql_select_scalar ('SELECT full_path FROM rubrics WHERE id = ?', $item -> {id_rubric});

	$item -> {path} = sql_select_path ('rubrics', $item -> {id_rubric}, {
		id_param => 'parent',
		name => 'label',
		root => '������� �����',
	});

	push @{$item -> {path}}, {
		type => 'articles',
		name => $item -> {label},
		id => $item -> {id}
	};
	
#	my $rubric_path = sql_select_path ('rubrics', $item -> {id_rubric}, {
#		id_param => 'parent',
#		name => 'label',
#		root => '������� �����',
#	});
#	my $article_path = sql_select_path ('articles', $item -> {id}, {
#		id_param => 'id',
#		name => 'label',
#	});	
#	$item -> {path} = [
#		@$rubric_path,
#		@$article_path,
#	];
			
	$item -> {images} = sql_select_all (<<EOS, $item -> {id});
		SELECT
			images.*
		FROM
			images
		WHERE
			images.id_article = ?
			and images.fake = 0
		ORDER BY
			images.ord
			, images.label
EOS

#	$item -> {comments} = sql_select_all (<<EOS, $item -> {id});
#		SELECT
#			comments.*
#			, external_users.label
#			, DATE_FORMAT(dt, '%d.%m.%Y %H:%i') AS dt
#		FROM
#			comments
#			INNER JOIN external_users ON comments.id_external_user = external_users.id
#		WHERE
#			comments.id_article = ?
#			and comments.fake = 0
#		ORDER BY
#			comments.dt DESC
#EOS

	return $item;
	
}

################################################################################

sub do_create_articles {
		
	$_REQUEST {id} = sql_do_insert ('articles', {
		id_rubric  => $_REQUEST {parent} || 0,
		is_visible => 0,
#		parent     => $_REQUEST {id_article} || 0,
		label      => '����� ����������',
		ord        => 10 * (1 + int (0.1 * ( sql_select_scalar ('SELECT MAX(ord) FROM articles WHERE id_rubric = ? AND fake = 0', $_REQUEST {parent} + 0)))),
	});
	
	my $name = $_REQUEST {id};
	my $parent_path = sql_select_scalar ('SELECT full_path FROM rubrics WHERE id = ?', $_REQUEST {parent});
	
#	if ($_REQUEST {id_article}) {
#		$parent_path = sql_select_scalar ('SELECT full_path FROM articles WHERE id = ?', $_REQUEST {id_article});
#		$name =  sprintf ('%04x', ($_REQUEST {id} - $_REQUEST {id_article}));
#	}
		
	sql_do ('UPDATE articles SET dt = NOW(), name = ?, full_path = ? WHERE id = ?',
		$name,
		$parent_path . '/' . $name,
		$_REQUEST {id}
	);

}

1;
