################################################################################

sub do_deny_users {	
	sql_do ('DELETE FROM map_users_to_rubrics WHERE id_user = ? AND id_rubric = ?', $_REQUEST {id}, $_REQUEST {id_rubric});
	delete $_REQUEST {id_rubric};	
}

################################################################################

sub get_item_of_users {

	my $item = sql_select_hash ("users");

	$item -> {roles} = sql_select_all ("SELECT id, label FROM roles WHERE fake = 0 ORDER BY id");

	$item -> {path} = [
		{type => 'users', name => '������������'},
		{type => 'users', name => $item -> {label}, id => $item -> {id}},
	];
		
	$item -> {rubrics} = sql_select_all (<<EOS, $item -> {id});
		SELECT
			rubrics.*
		FROM
			map_users_to_rubrics
			INNER JOIN rubrics ON map_users_to_rubrics.id_rubric = rubrics.id
		WHERE
			map_users_to_rubrics.id_user = ?
		ORDER BY
			rubrics.full_path
EOS

	return $item;
	
}

################################################################################

sub do_update_users {
	$_REQUEST {_label} = $_REQUEST {_f} . ' ' . $_REQUEST {_i} . ' ' . $_REQUEST {_o};
	sql_do_update ('users', [qw(f i o label login id_role)]);
	$_REQUEST {_password} and sql_do ("UPDATE users SET password=PASSWORD(?) WHERE id=?", $_REQUEST {_password}, $_REQUEST {id});
}

################################################################################

sub validate_update_users {
	my $cnt = sql_select_array ("SELECT COUNT(*) FROM users WHERE login = ? AND id <> ? AND fake = 0", $_REQUEST {_login}, $_REQUEST {id});
	return $cnt ? 'duplicate_login' : undef;
}

################################################################################

sub do_delete_users {
	sql_do ("DELETE FROM users WHERE id = ?", $_REQUEST {id});
	delete $_REQUEST {id};
}

################################################################################

sub do_create_users {
	$_REQUEST {id} = sql_do_insert ('users', {
		label => '������� �. �.',
		id_role => sql_select_scalar ('SELECT id FROM roles WHERE name = ?', 'editor'),
	});
}

################################################################################

sub select_users {

	my $q = '%' . $_REQUEST {q} . '%';
	
	my $start = $_REQUEST {start} + 0;
	
	my ($users, $cnt)= sql_select_all_cnt (<<EOS, $q, $q);
		SELECT
			users.*
			, roles.label AS role_label
		FROM
			users
			LEFT JOIN roles ON users.id_role = roles.id
		WHERE
			(users.label LIKE ? or users.login LIKE ?)
			and users.fake = 0
		ORDER BY
			users.label
		LIMIT
			$start, 50 #$$conf{portion}
EOS

	return {
		users => $users,
		cnt => $cnt,
		portion => 50,
	};	

}

1;
