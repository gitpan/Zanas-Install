################################################################################

sub do_add_select_rubrics {

	while (my ($key, $value) = each %_REQUEST) {
		$key =~ /_rubric_(\d+)/ or next;
		sql_do ('INSERT INTO map_users_to_rubrics (id_user, id_rubric) VALUES (?, ?)', $_REQUEST {id_user}, $1);
	}
	
	$_REQUEST {type} = 'users';
	$_REQUEST {id}   = $_REQUEST {id_user};
	delete $_REQUEST {id_user};
	
}

################################################################################

sub select_select_rubrics {

	my $select_rubrics = sql_select_all (<<EOS);
		SELECT
			rubrics.*
			, map_users_to_rubrics.id AS id_map
		FROM
			rubrics
			LEFT JOIN map_users_to_rubrics ON (map_users_to_rubrics.id_rubric = rubrics.id AND map_users_to_rubrics.id_user = $_REQUEST{id_user})
		WHERE
			rubrics.fake = 0
		ORDER BY
			rubrics.full_path
EOS

	return {
		select_rubrics => $select_rubrics,
	};
	
}

1;
