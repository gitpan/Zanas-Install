################################################################################

sub do_delete_rubrics {
	$_REQUEST {parent} = sql_select_scalar ('SELECT parent FROM rubrics WHERE id = ?', $_REQUEST {id});
	sql_do_delete ('rubrics');
	delete $_REQUEST {id};
}

################################################################################

sub do_toggle_rubrics {

	sql_do ('UPDATE rubrics SET is_visible = 1 - is_visible WHERE id = ?', $_REQUEST {id});
	
	my $full_path = sql_select_scalar ('SELECT full_path FROM rubrics WHERE id = ?', $_REQUEST {id});
	
	sql_select_loop ('SELECT id, full_path FROM rubrics WHERE full_path LIKE ?', sub {
		
		my $product_is_visible = 1;
		my $id = $i -> {id};
		my $is_visible;
		
		while (1) {
			$id or last;
			$product_is_visible or last;
			($id, $is_visible) = sql_select_array ('SELECT parent, is_visible FROM rubrics WHERE id = ?', $id);
			$product_is_visible *= $is_visible;
		}
		
		sql_do ('UPDATE rubrics SET product_is_visible = ? WHERE id = ?', $product_is_visible, $i -> {id});
		
	}, $full_path . '%');
	
	if ($_REQUEST {list}) {
		$_REQUEST {parent} = sql_select_scalar ('SELECT parent FROM rubrics WHERE id = ?', $_REQUEST {id});
		delete $_REQUEST {id};
	}
	
}

################################################################################

sub validate_update_rubrics {

#	$_REQUEST {_name} or return 'empty_name';
	$_REQUEST {_label} or return 'empty_label';

	$_REQUEST {_name} =~ /\w*/ or return 'invalid_name';

	my $parent = sql_select_scalar ('SELECT parent FROM rubrics WHERE id = ?', $_REQUEST {id});
        return 'duplicated_name' if sql_select_scalar ('SELECT COUNT(*) FROM rubrics WHERE parent = ? AND id <> ? AND fake = 0 AND name = ?', $parent, $_REQUEST {id}, $_REQUEST {_name});

	return undef;
	
}

################################################################################

sub do_update_rubrics {

	my $item = sql_select_hash ('rubrics');

	$_REQUEST {_name} ||= $_REQUEST {id};
	$_REQUEST {_full_path} = join '/', (sql_select_scalar ('SELECT full_path FROM rubrics WHERE id = ?', $item -> {parent}), $_REQUEST {_name});
	
	sql_do_update ('rubrics', [qw(label name full_path ord portion body announce)]);
	
	if ($_REQUEST {_photo}) {
	
		my $uploaded = sql_upload_file ({
			name             => 'photo',
			table            => 'rubrics',
			dir		 => 'upload/images',
			path_column      => 'path_photo',
			type_column      => 'type_photo',
			file_name_column => 'flnm_photo',
			size_column      => 'size_photo',
		});	
	
	}

	sql_do ('UPDATE rubrics SET full_path = REPLACE(full_path, ?, ?) WHERE full_path LIKE ?',
		$item -> {full_path} . '/',
		$_REQUEST {_full_path} . '/',
		$item -> {full_path} . '/%',
	) if $item -> {full_path};

	sql_do ('UPDATE articles SET full_path = REPLACE(full_path, ?, ?) WHERE full_path LIKE ?',
		$item -> {full_path} . '/',
		$_REQUEST {_full_path} . '/',
		$item -> {full_path} . '/%',
	) if $item -> {full_path};
	
}

################################################################################

sub do_create_rubrics {

	$_REQUEST {id} = sql_do_insert ('rubrics', {
		parent     => $_REQUEST {parent} || 0,
		is_visible => 0,
		label      => '����� �������',
		ord        => 10 * (1 + int (0.1 * ( sql_select_scalar ('SELECT MAX(ord) FROM rubrics WHERE parent = ? AND fake = 0', $_REQUEST {parent} + 0)))),
	});
	
	sql_do ('UPDATE rubrics SET full_path = ? WHERE id = ?',
		sql_select_scalar ('SELECT full_path FROM rubrics WHERE id = ?', $_REQUEST {parent}) . '/' . $_REQUEST {id},
		$_REQUEST {id},
	);

}

################################################################################

sub get_item_of_rubrics {
	
	my $item = sql_select_hash ("SELECT *, $SQL_STATUS as status FROM rubrics WHERE id = ?", $_REQUEST {id});

	$item -> {path} = sql_select_path ('rubrics', $_REQUEST {parent}, {
		id_param => 'parent',
		name => 'label',
		root => '������� �����',
	});
	
	return $item;

}

################################################################################

sub select_rubrics {

	$_REQUEST {parent} ||= 0;
	
	my $rubric_path = sql_select_scalar ('SELECT full_path FROM rubrics WHERE id = ?', $_REQUEST {parent});
	
#	my $order = $rubric_path eq '/forum' ? 'rubrics.created DESC' : 'rubrics.ord, rubrics.label';
	my $order = 'rubrics.ord, rubrics.label';

	my $rubrics = sql_select_all (<<EOS, $_REQUEST {parent});
		SELECT
			rubrics.*
			, $SQL_STATUS as status
		FROM
			rubrics
		WHERE
			rubrics.parent = ?
			and rubrics.fake = 0
		ORDER BY
			$order
EOS

	my $parent_is_own;
	
	if ($_USER -> {role} eq 'editor') {
		
		$_USER -> {own_rubrics} = sql_select_all (<<EOS, $_USER -> {id});
			SELECT
				rubrics.*
			FROM
				map_users_to_rubrics
				INNER JOIN rubrics ON map_users_to_rubrics.id_rubric = rubrics.id
			WHERE
				map_users_to_rubrics.id_user = ?
EOS

		foreach my $rubric (@$rubrics) {		
			$rubric -> {is_own} = grep {$rubric -> {full_path} =~ /^$$_{full_path}/} @{$_USER -> {own_rubrics}};
		}
		
		my $parent_full_path = sql_select_scalar ('SELECT full_path FROM rubrics WHERE id = ?', $_REQUEST {parent});
		
		$parent_is_own = grep {$parent_full_path =~ /^$$_{full_path}/} @{$_USER -> {own_rubrics}};
	
	}
	else {
		map {$_ -> {is_own} = 1} @$rubrics;
		$parent_is_own = 1;
	}

	my $start = $_REQUEST {start} + 0;
	my $order = ($rubric_path =~ m{^/news} || $rubric_path =~ m{^/guestbook} || $rubric_path =~ m{^/forum} ? 'articles.dt DESC' : 'articles.ord');
	my ($articles, $articles_cnt)= sql_select_all_cnt (<<EOS, $_REQUEST {parent});
		SELECT
			articles.*
		FROM
			articles
		WHERE
			articles.id_rubric = ?
			AND articles.fake = 0
#			AND articles.parent = 0
		ORDER BY
			$order
		LIMIT
			$start, $$conf{portion}
EOS

	my $path = sql_select_path ('rubrics', $_REQUEST {parent}, {
		name => 'label',
		id_param => 'parent',
		root => '������� �����',
	}),
	
	ref $path;
	
	return {
		rubrics => $rubrics,
		parent_is_own => $parent_is_own,
		path => $path,
		articles => $articles,
		articles_cnt => $articles_cnt,
		articles_portion => $conf -> {portion},
		properties => $properties,
		rubric_path => $rubric_path,
	};
}

1;
