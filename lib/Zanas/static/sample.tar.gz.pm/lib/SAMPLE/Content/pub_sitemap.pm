################################################################################

sub select_pub_sitemap {

	my $rubrics = sql_select_all  ("SELECT id, label, full_path FROM rubrics WHERE parent = 0 AND product_is_visible = 1 ORDER BY ord");
	
	foreach my $i (@$rubrics) {
	
		my $articles   = sql_select_all  ("SELECT id, label, full_path, '' AS slash FROM articles WHERE id_rubric = ? AND is_visible = 1 ORDER BY ord", $i -> {id});
		my $subrubrics = sql_select_all  ("SELECT id, label, full_path, '/' AS slash FROM rubrics  WHERE parent = ? AND product_is_visible = 1 ORDER BY ord", $i -> {id});
		
		$i -> {items}  = [@$subrubrics, @$articles];
		
		foreach my $j (@$subrubrics) {

			my $articles   = sql_select_all  ("SELECT id, label, full_path, '' AS slash FROM articles WHERE id_rubric = ? AND is_visible = 1 ORDER BY ord", $j -> {id});
			my $subrubrics = sql_select_all  ("SELECT id, label, full_path, '/' AS slash FROM rubrics  WHERE parent = ? AND product_is_visible = 1 ORDER BY ord", $j -> {id});

                     	$j -> {items}  = [@$subrubrics, @$articles];

		}
	
	}
	
	return {
		rubrics => $rubrics,
	};
	
}

1;
