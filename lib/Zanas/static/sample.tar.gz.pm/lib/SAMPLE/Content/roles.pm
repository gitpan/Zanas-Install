################################################################################

sub select_roles {

	my $roles = sql_select_all (<<EOS);
		SELECT
			roles.id
			, roles.name
			, roles.label
		FROM
			roles
		WHERE
			fake = 0
		ORDER BY
			roles.label
EOS
	
	return {
		roles => $roles,
	};

}

################################################################################

sub get_item_of_roles {
	my $role = sql_select_hash ("SELECT * FROM roles WHERE id = ?", $_REQUEST {id});
	$role -> {path} = [
		{type => 'roles', name => '����'},
		{type => 'roles', name => $role -> {label}, id => $role -> {id}},
	];
	return $role;
}

################################################################################

sub do_delete_roles {
	sql_do ("DELETE FROM roles WHERE id = ?", $_REQUEST {id});
	delete $_REQUEST {id};
}

################################################################################

sub do_create_roles {
	sql_do ("INSERT INTO roles (label, fake) VALUES (?, ?)", '����� ����', $_REQUEST {sid});
	$_REQUEST {id} = sql_last_insert_id ();
}

################################################################################

sub do_update_roles {
#	sql_do ("UPDATE roles SET fake=0, name=?, label=?, home_html=? WHERE id=?", $_REQUEST {_name}, $_REQUEST {_label}, $_REQUEST {id});
	sql_do_update ('roles', [qw(name label)]);
}

################################################################################

sub validate_update_roles {
	my $cnt = sql_select_array ("SELECT COUNT(*) FROM roles WHERE name = ? AND id <> ? AND fake = 0", $_REQUEST {_name}, $_REQUEST {id});
	return $cnt ? 'duplicate_name' : undef;
}

1;
