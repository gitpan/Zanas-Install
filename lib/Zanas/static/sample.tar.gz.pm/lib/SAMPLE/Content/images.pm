################################################################################

sub validate_update_images {

	return undef;
	
}

################################################################################

sub do_delete_images {
	
	$_REQUEST {id_doc} = sql_select_scalar ('SELECT id_article FROM images WHERE id = ?', $_REQUEST {id});
	
	sql_do_delete ('images', {
		file_path_columns => ['path_photo'],
	});
	
	delete $_REQUEST {id};
	
	if ($_REQUEST {list}) {
		$_REQUEST {id} = $_REQUEST {id_doc};
		$_REQUEST {type} = 'articles';
	}
}

################################################################################

sub do_update_images {

	my $uploaded = sql_upload_file ({
		name             => 'photo',
		table            => 'images',
		dir		 => 'upload/images',
		path_column      => 'path_photo',
		type_column      => 'type_photo',
		file_name_column => 'flnm_photo',
		size_column      => 'size_photo',
	});
	
	my ($width, $height) = imgsize ($uploaded -> {real_path});
	
	$_REQUEST {_width}  ||= $width;
	$_REQUEST {_height} ||= $height;
	$_REQUEST {_border} ||= 0;
	$_REQUEST {_hspace} ||= 5;
	$_REQUEST {_vspace} ||= 5;

       	sql_do_update ('images', [qw(label width height border hspace vspace align ord)]);

}

################################################################################

sub get_item_of_images {

	my $item = sql_select_hash ('images');
	
#	add_vocabularies ($item, 'colors');
	
	my $article = sql_select_hash ('SELECT * FROM articles WHERE id = ?', $item -> {id_article});

	$item -> {path} = sql_select_path ('rubrics', $article -> {id_rubric}, {
		id_param => 'parent',
		name => 'label',
		root => '������� �����',
	});

	push @{$item -> {path}}, {
		type => 'articles',
		name => $article -> {label},
		id => $article -> {id}
	};

	push @{$item -> {path}}, {
		type => 'images',
		name => $item -> {label},
		id => $item -> {id}
	};

	return $item;
}

################################################################################

sub do_create_images {

	$_REQUEST {id} = sql_do_insert ('images', {
		id_article => $_REQUEST {id_doc},
		label  => '����� �����������',
	});

}

################################################################################

sub select_images {

	my $images = sql_select_all (<<EOS, $_REQUEST {id_doc});
		SELECT
			images.*
		FROM
			images
		WHERE
			images.id_article = ?
			and images.fake = 0
		ORDER BY
			images.label
EOS

	return {
		images => $images,
	};
}

1;
