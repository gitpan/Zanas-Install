################################################################################

sub get_page {

	my $menu = call_for_role ('get_menu');
	
	my $type = $_REQUEST {type};
	$type ||= $menu -> [0] -> {name};

	my $highlighted_type = 
		$type =~ '^forum' ? 'forum' :
		$type =~ '^doc' ? 'docs' :
		$type eq 'news_public' ? 'news' :
		$type eq 'workgroup_members' ? 'workgroups' :
		$type;

	return {
		menu => $menu,
		type => $type,
		highlighted_type => $highlighted_type,
	};

}

1;