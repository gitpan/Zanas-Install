################################################################################

sub get_item_of_pub_content {

	my $article = sql_select_hash ('SELECT * FROM articles WHERE id = ?', $_PAGE -> {id});
	
	$_PAGE -> {title} = $article -> {label};
	
	push @{$_PAGE -> {path}}, {name => $article -> {label}, full_path => $article -> {full_path}};

	return {
		article => $article,
	}

}

################################################################################

sub select_pub_content {

	my $rubric = sql_select_hash ('SELECT * FROM rubrics WHERE id = ?', $_PAGE -> {id_rubric});

	my $articles = sql_select_all (<<EOS, $_PAGE -> {id_rubric});
			SELECT
				id
				, full_path
				, label
				, announce
			FROM
				articles
			WHERE
				id_rubric = ?
				AND is_visible = 1
			ORDER BY
				articles.ord
EOS

	my $rubrics = sql_select_all (<<EOS, $_PAGE -> {id_rubric});
			SELECT
				id
				, full_path
				, label
				, announce
			FROM
				rubrics
			WHERE
				parent = ?
				AND product_is_visible = 1
			ORDER BY
				rubrics.ord
EOS

	return {
		rubric => $rubric,
		rubrics => $rubrics,
		articles => $articles,
	}

}

1;
