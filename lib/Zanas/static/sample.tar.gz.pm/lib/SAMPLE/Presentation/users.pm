################################################################################

sub draw_item_of_users {

	my ($data) = @_;
	
	draw_form ({esc => "/?type=phones&parent=$$data{id_department}"}, $data, 
		[
			[
				{
					name  => 'f',
					label => '�������',
					size  => 30,
				},
				{
					name  => 'i',
					label => '���',
					size  => 30,
				},
				{
					name  => 'o',
					label => '��������',
					size  => 30,
				},
			],
			{
				name  => 'label',
				label => '���',
				type  => 'static',
			},
			{
				name  => 'birthday',
				label => '���� ��������',
				type  => 'datetime',
				no_time => 1,
			},
			{
				name  => 'mail',
				label => 'E-mail',
			},			
			[
				{
					name  => 'phone',
					label => '������� ���.',
					size  => 30,
				},
				{
					name  => 'mobile',
					label => '������� ���.',
					size  => 30,
				},
			],
			{
				name  => 'login',
				mandatory  => 1,
				label => '&login',
			},
			{
				name  => 'password',
				label => '�����&�',
				type  => 'password',
			},
			[
			{
				name  => 'room',
				label => '�������',
				size  => 3,
			},
			{
				name   => 'building',
				label  => '������',
				type   => 'select',
				empty  => '&lt;���&gt;',
				values => $building_names,
#				values => [map {id => $_, label => $building_names -> {$_}}, keys %$building_names],
			},
			],
			{
				name   => 'id_position',
				label  => '���������',
				type   => 'select',
				values => $data -> {positions},
			},
			{
				name   => 'id_role',
				label  => '����',
				type   => 'select',
				values => $data -> {roles},
			},
			{
				name   => 'id_department',
				label  => '�����',
				type   => 'select',
				empty  => '&lt;�������&gt;',
				values => $data -> {departments},
			},
		]
	);
	
}

################################################################################

sub draw_item_of_users_for_phones_editor {

	my ($data) = @_;
	
	draw_form ({esc => "/?type=phones&parent=$$data{id_department}"}, $data, 
		[
			[
			{
				name  => 'f',
				label => '�������',
				size  => 30,
			},
			{
				name  => 'i',
				label => '���',
				size  => 30,
			},
			{
				name  => 'o',
				label => '��������',
				size  => 30,
			},
			],
			{
				name  => 'label',
				label => '���',
				type  => 'static',
			},
			{
				name  => 'mail',
				label => 'E-mail',
			},
			{
				name  => 'phone',
				label => '�������',
			},
			[
			{
				name  => 'room',
				label => '�������',
				size  => 3,
			},
			{
				name   => 'building',
				label  => '������',
				type   => 'select',
				empty  => '&lt;���&gt;',
				values => $building_names,
#				values => [map {id => $_, label => $building_names -> {$_}}, keys %$building_names],
			},
			],
			{
				name   => 'id_position',
				label  => '���������',
				type   => 'select',
				values => $data -> {positions},
			},
			{
				name   => 'id_department',
				label  => '�����',
				type   => 'select',
				empty  => '&lt;�������&gt;',
				values => $data -> {departments},
			},
		]
	);
	
}

################################################################################

sub draw_users {
	
	my ($data) = @_;
	
	return
	
		draw_hr (height => 10)
		
		.
	
		draw_window_title ({
			label => '������������'
		})
	
		.
		
		draw_toolbar (
		
			{},
			
			draw_toolbar_button ({
				icon => 'create',
				label => '&��������',
				href => "?type=users&action=create",
			}),

			draw_toolbar_input_text ({
				icon   => 'tv',
				label  => '������',
				name   => 'q',
			}),
			
			draw_toolbar_pager ({
				cnt    => 0 + @{$data -> {users}},
				total  => $data -> {cnt},
				portion => $data -> {portion},
			})
			
		)
		
		.

		draw_table (
		
			['', '���', '����', '�����', 'login', ''],

			sub { 

				draw_row_buttons ({},
					[
						{icon => 'edit', label => '�������������', href => "/?type=users&id=$$i{id}"},
					]
				)
				
				.
				
				draw_text_cell ({
					label => $i -> {label},
					href  => "/?type=users&id=$$i{id}",
				})

				.

				draw_text_cell ({
					label => $i -> {role_label},
					href  => "/?type=users&id=$$i{id}",
				})

				.

				draw_text_cell ({
					label => $i -> {department_label},
					href  => "/?type=users&id=$$i{id}",
				})

				.

				draw_text_cell ({
					label => $i -> {login},
					href  => "/?type=users&id=$$i{id}",
				})

#				.
							
#				draw_row_buttons ({},
#					[
#						{icon => 'logon', label => '����', href => "/?type=logon&action=execute&login=$$i{login}&password=$$i{password}", target => '_blank'},
#					]
#				)
				
				.
							
				draw_row_buttons ({},
					[
						{icon => 'delete', label => '�������', href => "/?type=users&action=delete&id=$$i{id}", confirm => "������� ������������ $$i{label}?"},
					]
				)
				
			}, 
			$data -> {users}
		)
		
}

1;