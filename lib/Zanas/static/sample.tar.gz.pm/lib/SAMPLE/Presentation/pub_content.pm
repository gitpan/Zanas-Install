################################################################################

sub draw_item_of_pub_content {

	my ($data) = @_;

	return <<EOH;

			<table width="100%" border="0" cellpadding="0" cellspacing="0">
				<tr valign="top">
					<td width="11"><img width="11" height="1" src="/i/images/1.gif" alt><br>
					</td>
					<td width="100%">
						
						${$$data{article}}{body}
					
						<div>
							<img height="4" width="1" src="/i/images/1.gif" alt><br>
						</div>
						
					</td>
					<td width="10"><img width="10" height="1" src="/i/images/1.gif" alt><br></td>
				</tr>
			</table>
	
EOH

	
}

################################################################################

sub draw_pub_content {

	my ($data) = @_;

	return <<EOH;
				<table width="100%" border="0" cellpadding="0" cellspacing="0">
				<tr valign="top">
					<td width="11"><img width="11" height="1" src="/i/images/1.gif" alt><br>
					</td>
					<td width="100%">
						
						${$$data{rubric}}{body}
					

						<div>
							<img height="4" width="1" src="/i/images/1.gif" alt><br>
						</div>

<!-- Docs -->
						<table width=100% border=0 cellspacing=0 cellpadding=0 cols=2>
						
							@{[ map {<<EOM} (@{$data -> {rubrics}}, @{$data -> {articles}}) ]}
								<tr>
									<td width=1 rowSpan=2 vAlign=top>
										<img width=16 height=16 src="/i/images/A0.gif" alt=""><br>
									</td>
									<td width=1 rowSpan=2 vAlign=top>
										<img width=10 height=10 src="/i/images/1.gif" alt=""><br>
									</td>
									<td width=100%>
										<a href="$$_{full_path}"><span  class=bsTitle>$$_{label}</span></a>
									</td>
								</tr>
								<tr>
									<td class=BriefText>$$_{announce}</td>
								</tr>
								<tr>
									<td colSpan=2><img width=20 height=10 src="/i/images/1.gif" alt=""><br></td>
								</tr>
EOM
						</table>

						<div style="padding: 1px;">
						</div>
						<div>
							<img height="4" width="1" src="/i/images/1.gif" alt><br>
						</div>

					</td>
					<td width="10"><img width="10" height="1" src="/i/images/1.gif" alt><br></td>
				</tr>
			</table>
	
EOH

	
}

1;
