################################################################################

sub draw_pub_sitemap {

	my ($data) = @_;
	
	my $body = '';	

	foreach my $i (@{$data -> {rubrics}}) {
	
		$body .= qq {<a href="$$i{full_path}$$i{slash}"><b>$$i{label}</b></a><div class=Menu>};
		
		foreach my $j (@{$i -> {items}}) {
		
			$body .= qq {&nbsp;&nbsp;&nbsp;<a href="$$j{full_path}$$j{slash}">$$j{label}</a><div class=Menu>};

			foreach my $k (@{$j -> {items}}) {
				$body .= qq {&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="$$k{full_path}$$k{slash}">$$k{label}</a><br>};
			}

			$body .= qq {</div>};
		
		}

		$body .= qq {</div>};
	
	}


	return <<EOH;
		<table width=100% cellspacing=0 cellpadding=0>
			<tr>
				<td><img width="30" height="1" src="/i/images/1.gif"></td>
				<td>$body</td>
				<td><img width="30" height="1" src="/i/images/1.gif"></td>
			</tr>
		</table>
EOH
	
}

1;
