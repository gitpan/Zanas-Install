################################################################################

sub draw_pub_page {

	$_REQUEST {print} and return <<EOH;
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML><HEAD><TITLE>$$_PAGE{title} - Zanas</TITLE>
<LINK href="/i/css/MSIE_5/Base-Basic.css" type=text/css rel=stylesheet>
<LINK href="/i/css/MSIE_5/Common-Basic.css" type=text/css rel=stylesheet>
<LINK href="/i/css/MSIE_5/Controls-Basic.css" type=text/css rel=stylesheet>
<LINK href="/i/css/MSIE_5/Containers-Basic.css" type=text/css rel=stylesheet>
<LINK href="/i/css/MSIE_5/Parts-Basic.css" type=text/css rel=stylesheet>

<BODY class=Base leftMargin=0 topMargin=0 marginheight="0" marginwidth="0">


			<div>
				<img height="10" width="1" src="/i/images/1W.gif" alt><br>
			</div>
			<table width="100%" border="0" cellspacing="0" cellpadding="0">
				<tr>
					<td bgcolor="#E1E1E1"><img width="1" height="1" src="/i/images/1.gif" alt><br>
					</td>
				</tr>
			</table>
			<table width="100%" border="0" cellspacing="0" cellpadding="0">
				<tr valign="middle">
					<td bgcolor="#E1E1E1"><img width="10" height="1" src="/i/images/1.gif" alt><br>
					</td>
					<td width="100%" class="bsCnerHeaderDocStdTitle" style="padding: 8px 10px; text-align: left;">$$_PAGE{title}<br>
					</td>					
				</tr>
			</table>
			<table width="100%" border="0" cellspacing="0" cellpadding="0">
				<tr>
					<td width="1" bgcolor="#E1E1E1"><img width="40" height="1" src="/i/images/1.gif" alt><br>
					</td>
					<td width="100%"><img width="1" height="1" src="/i/images/1.gif" alt><br>
					</td>
				</tr>
			</table>
			<div>
				<img height="10" width="1" src="/i/images/1.gif" alt><br>
			</div>


	$$_PAGE{body}
</BODY>
</HTML>
EOH

	return <<EOH;
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML><HEAD><TITLE>$$_PAGE{title} - Zanas</TITLE>
<LINK href="/i/css/MSIE_5/Base-Basic.css" type=text/css rel=stylesheet>
<LINK href="/i/css/MSIE_5/Common-Basic.css" type=text/css rel=stylesheet>
<LINK href="/i/css/MSIE_5/Controls-Basic.css" type=text/css rel=stylesheet>
<LINK href="/i/css/MSIE_5/Containers-Basic.css" type=text/css rel=stylesheet>
<LINK href="/i/css/MSIE_5/Parts-Basic.css" type=text/css rel=stylesheet>
<BODY class=Base leftMargin=0 topMargin=0 marginheight="0" marginwidth="0">
<TABLE cellSpacing=0 cellPadding=0 width="100%" border=0>
  <TBODY>
  <TR>
    <TD>
      <TABLE cellSpacing=0 cellPadding=0 width="100%" border=0>
        <TR vAlign=top>
          <TD width="100%" bgColor="#ededed">

            <TABLE cellSpacing=0 cellPadding=0 width="100%" border=0>
		<TR>
			<TD><IMG hspace=0 vspace=0 height=5 src="/i/0.gif" width=1 border=0></TD>
		</TR>
		<TR>
			<TD bgcolor="#bbbbbb"><IMG hspace=0 vspace=0 height=1 src="/i/0.gif" width=1 border=0></TD>
		</TR>
		<TR>
			<TD>
				<A href="/"><IMG hspace=20 vspace=5 height=50 alt="" src="/i/images/zanas_mascot_50_50.gif" width=50 border=0 align=absmiddle></A>
				<font face="Courier New" size="+4"><b>������ ZANAS</b></font>
			</TD>
		</TR>
		<TR>
			<TD bgColor="#bbbbbb"><IMG height=1 alt="" src="/i/0.gif" width=1></TD>
		</TR>
              <TR>
                <TD bgColor="#e1e1e1">


                  <TABLE cellSpacing=0 cellPadding=0 width="100%" border=0>
                    <TBODY>
                    <TR vAlign=center>
                      <TD align=middle width=170 background="/i/images/Line2BgL.gif">
						<IMG height=1 alt="" src="/i/images/1.gif" width=170><BR>
                        <TABLE cellSpacing=0 cellPadding=0 border=0>
                          <TBODY>
                          <TR vAlign=center>
						<form name="quicksearch" action="/search/">
                            <TD><INPUT class=bsESearch size=10 name="q"></TD>
                            <TD><IMG height=1 alt="" src="/i/images/1.gif" width=2></TD>
                            <TD><INPUT class=bImageButton type=image height=13 alt="�����!" width=13 src="/i/images/Go.gif"></TD></TR>
						</form>
                          </TBODY>
                        </TABLE>
		      </TD>
		
		      @{[ map {<<EOM} @{$_PAGE -> {high_menu}} ]}
			<TD class=bsHead width=1 background="/i/images/Line2BgM.gif">
				<DIV style="PADDING-RIGHT: 8px; PADDING-LEFT: 8px; PADDING-BOTTOM: 0px; PADDING-TOP: 0px">
					<IMG height=6 alt="" src="/i/images/1.gif" width=1><BR>
					<NOBR><A href="$$_{full_path}/">$$_{label}</A></NOBR><BR>
					<IMG height=6 alt="" src="/i/images/1.gif" width=1><BR>
				</DIV>
			</TD>
EOM

<!-- ������� ���� - ����� ������� -->
                      <TD width="100%" background="/i/images/Line2BgM.gif"><BR></TD>
                      <TD class=bsHead width=1 background="/i/images/Line2BgR.gif">
                        <DIV style="PADDING-RIGHT: 8px; PADDING-LEFT: 8px; PADDING-BOTTOM: 0px; PADDING-TOP: 0px">
									<SELECT onchange=location.replace(this.value) size=1>
			<OPTION value="/">�������� ������...</OPTION>			
			
			@{[ map {<<EOM} (@{$_PAGE -> {main_menu}}, @{$_PAGE -> {high_menu}}) ]}
				<OPTION value="$$_{full_path}/" @{[ $$_{active} ? 'selected' : '' ]}>$$_{label}</OPTION>
EOM
		</SELECT>

</DIV></TD></TR>
                  </TABLE>
                </TD>
              </TR><!-- Line 4 -->



              <TR>
                <TD bgColor="#e1e1e1">
<!-- ������ ��� ������� ����  -->
                  <TABLE cellSpacing=0 cellPadding=0 width="100%" border=0>
                    <TBODY>
                    <TR>
                      <TD width=1><IMG height=1 alt="" src="/i/images/1.gif" width=1><BR></TD>
                      <TD bgColor="#bbbbbb" colSpan=10><IMG height=1 alt="" src="/i/images/1.gif" width=1><BR></TD></TR>
                    <TR vAlign=center>
                      <TD width=1><IMG height=1 alt="" src="/i/images/1.gif" width=43><BR></TD>
                      <TD width=1 bgColor="#bbbbbb"><IMG height=1 alt="" src="/i/images/1.gif" width=1><BR></TD>
                      <TD width=1><A href="/">
						<IMG height=18 alt="�� ������� ��������" src="/i/images/Home.gif" width=25 border=0><BR></A>
					  </TD>


                      <TD width=1 bgColor="#bbbbbb"><IMG height=1 alt="" src="/i/images/1.gif" width=1><BR></TD>

<!-- ����� �������� �������� -->
                      <TD class=bsHead align=middle width=100 bgColor="#f0f0f0">
						<IMG height=1 alt="" src="/i/images/1.gif" width=100><BR>
						<A class=bsHeadRed href="/">www.zanas.ru</A><BR>
						<IMG height=2 alt="" src="/i/images/1.gif" width=100><BR></TD>
                      <TD width=1 bgColor="#bbbbbb">
						<IMG height=1 alt="" src="/i/images/1.gif" width=1><BR></TD>

<!-- ��������� -->
                      	<TD class=bsHeadPath width="100%" bgColor=white>
                      	
		                <DIV style="PADDING-RIGHT: 8px; PADDING-LEFT: 8px; PADDING-BOTTOM: 0px; PADDING-TOP: 0px">
                      			@{[ map {<<EOM} @{$_PAGE -> {path}} ]}
						<IMG height=5 alt="" src="/i/images/PathArrow.gif" width=7>
						<A href="$$_{full_path}">$$_{name}</A>
EOM
		                </DIV>
			</TD>

                      <TD width=1 bgColor="#bbbbbb">
						<IMG height=1 alt="" src="/i/images/1.gif" width=1><BR></TD>
                      <TD width=1><IMG height=1 alt="" src="/i/images/1.gif" width=1><BR></TD></TR>
                    <TR>
                      <TD width=1><IMG height=1 alt="" src="/i/images/1.gif" width=1><BR></TD>
                      <TD bgColor="#bbbbbb" colSpan=10>
						<IMG height=1 alt="" src="/i/images/1.gif" width=1><BR></TD>
                    </TR></TBODY>
                  </TABLE>
                </TD></TR>
            </TBODY>
            </TABLE>

          </TD>
          <TD width=1><IMG height=1 alt="" src="/i/images/1.gif" width=1><BR></TD>
          <TD width=1 bgColor="#336699"><IMG height=1 alt="" src="/i/images/1.gif" width=9><BR></TD></TR>
        </TBODY>
      </TABLE>

<!-- ����� ������� ����� -->
		<table width="100%" border="0" cellpadding="0" cellspacing="0">
	<!-- Gray Line  -->
	<tr>
		<td colspan="2" bgcolor="#E1E1E1">
			<table width="100%" border="0" cellpadding="0" cellspacing="0">
				<tr>
					<td width="1"><img width="250" height="5" src="/i/images/1.gif" alt><br>
					</td>
					<td width="1" bgcolor="#BBBBBB"><img width="1" height="1" src="/i/images/1.gif" alt><br>
					</td>
					<td width="100%"><img width="1" height="1" src="/i/images/1.gif" alt><br>
					</td>
				</tr>
			</table>
		</td>
	</tr>
	<tr>
		<td colspan="2" bgcolor="#E1E1E1"><img width="1" height="5" src="/i/images/1.gif" alt><br>
		</td>
	</tr>
	<!-- Menu, Calendar, etc... -->
	<tr valign="top">
		<td width="25%" style="background-image: url('/i/images/LeftCol20.gif'); background-repeat: repeat-y; background-attachment: scroll; background-position: 0%">
					<TABLE cellSpacing=0 cellPadding=0 width="100%" border=0>
			<TBODY>
			
			
			
			
			
			
			
			<TR vAlign=top>
				<TD vAlign=top width=32>
					<IMG height=186 alt="" src="/i/images/1.gif" width=32><BR>
				</TD>

				<TD vAlign=top width="100%">
					<TABLE cellSpacing=0 cellPadding=0 width="100%" border=0>
					<TBODY>
					
					
					
					
					
		@{[ map {<<EOM} @{$_PAGE -> {main_menu}} ]}
			<TR>
				<TD width=1>
					<IMG height=19 alt="" src="/i/images/L1A$$_{active}.gif" width=20><BR>
				</TD>
				<TD class=bsMainMenuL1$$_{active} width="100%">
					<A href="$$_{full_path}/">$$_{label}</A>
				</TD>
			</TR>
			<TR bgColor="#e1e1e1">
				<TD colSpan=2>
					<IMG height=1 alt="" src="/i/images/1.gif" width=1><BR>
				</TD>
			</TR>
EOM
					
					


						<TR>
							<TD width=1>
								<IMG height=9 alt="" src="/i/images/1.gif" width=20><BR>
							</TD>
							<TD width="100%">
								<IMG height=9 alt="" src="/i/images/1.gif" width=115><BR>
							</TD>
						</TR>
					</TBODY>
					</TABLE>
				</TD>
			</TR>
		</TBODY>
		</TABLE>


			<table width="100%" border="0" cellspacing="0" cellpadding="0">
				<tr>
					<td width="1" bgcolor="#677A8D"><img width="10" height="10" src="/i/images/1.gif" alt><br>
					</td>
					<td width="100%" bgcolor="white"><img width="10" height="10" src="/i/images/1.gif" alt><br>
					</td>
				</tr>
				<tr bgcolor="#E1E1E1">
					<td colspan="2"><img width="1" height="1" src="/i/images/1.gif" alt><br>
					</td>
				</tr>
			</table>

			<!-- Actual Materials -->


			<table width="100%" border="0" cellspacing="0" cellpadding="0">
				<tr>
					<td width="1" bgcolor="#677A8D"><img width="10" height="10" src="/i/images/1.gif" alt><br>
					</td>
					<td width="100%" bgcolor="white"><img width="10" height="10" src="/i/images/1.gif" alt><br>
					</td>
				</tr>
			</table>

			<!-- LeftColumn Banners -->

			
			<div>
				<img width="1" height="90" src="/i/images/1.gif" alt><br>
			</div>
		</td>
		<td width="1%"><img width="10" height="10" src="/i/images/1W.gif" alt><br>
		</td>
		<td width="60%" style="background-image: url('/i/images/RightCol11.gif'); background-repeat: repeat-y; background-attachment: scroll; background-position: 0%">









			<div>
				<img height="10" width="1" src="/i/images/1W.gif" alt><br>
			</div>
			<table width="100%" border="0" cellspacing="0" cellpadding="0">
				<tr>
					<td bgcolor="#E1E1E1"><img width="1" height="1" src="/i/images/1.gif" alt><br>
					</td>
				</tr>
			</table>
			<table width="100%" border="0" cellspacing="0" cellpadding="0">
				<tr valign="middle">
					<td bgcolor="#E1E1E1"><img width="10" height="1" src="/i/images/1.gif" alt><br>
					</td>
					<td width="100%" class="bsCnerHeaderDocStdTitle" style="padding: 8px 10px; text-align: left;">$$_PAGE{title}<br>
					</td>					
					@{[ $_REQUEST {print} ? '' : <<EOP]}
						<td class="bsCnerHeaderDocStdOps" style="padding: 2px 4px;" valign="top" align="right"><nobr>
							<a href="$_REQUEST{__uri}?print=yes&id=$_REQUEST{id}" target="_blank">
								<img width="13" height="10" border="0" src="/i/images/PrintVersion.gif" alt="������ ��� ������">������ ��� ������
							</a></nobr><br>
						</td>
EOP

				</tr>
			</table>
			<table width="100%" border="0" cellspacing="0" cellpadding="0">
				<tr>
					<td width="1" bgcolor="#E1E1E1"><img width="40" height="1" src="/i/images/1.gif" alt><br>
					</td>
					<td width="100%"><img width="1" height="1" src="/i/images/1.gif" alt><br>
					</td>
				</tr>
			</table>
			<div>
				<img height="10" width="1" src="/i/images/1.gif" alt><br>
			</div>





			$$_PAGE{body}
									
			<div>
				<img height="90" width="1" src="/i/images/1.gif" alt><br>
			</div>
		</td>
		<td width="1%" bgcolor="#E1E1E1">
			<table width="10" height="10" border="0" cellspacing="0" cellpadding="0">
				<tr>
					<td bgcolor="white"><img width="10" height="10" src="/i/images/1.gif" alt><br>
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table>
	




<!-- Footer -->
      <TABLE cellSpacing=0 cellPadding=0 width="100%" border=0>
        <TBODY>
        <TR>
          <TD bgColor="#dedebf"><IMG height=20 alt="" src="/i/images/1.gif" width=1><BR></TD></TR>
		</TBODY>
	  </TABLE>

<!-- White Line -->

      <TABLE cellSpacing=0 cellPadding=0 width="100%" border=0>
        <TBODY>
        <TR>
          <TD><IMG height=20 alt="" src="/i/images/1.gif" width=1><BR></TD>
		</TR>
		</TBODY>
	  </TABLE>

<!-- Contact Info -->
      <DIV style="POSITION: relative">
      <DIV style="POSITION: absolute; TOP: -100px">
      <TABLE cellSpacing=0 cellPadding=1 border=0>
        <TBODY>
        <TR>
          <TD bgColor="#dedebf">
            <TABLE cellSpacing=0 cellPadding=0 width="100%" border=0>
              <TBODY>
              <TR>
                <TD bgColor="#dedebf">
					<IMG height=90 alt="" src="/i/images/1.gif" width=9><BR></TD>
                <TD vAlign=top bgColor=white>
                  <TABLE cellSpacing=0 cellPadding=10 width="100%" border=0>
                    <TBODY>
                    <TR vAlign=top>
                      <TD class=bsFoot><B>���������� ����������</B>
		    	    <BR><a href="/about/map">109074, ���������� �������, 4, ���. 1</a>,
			    <BR>���. (095) 289-54-00,
			    <BR>���� (095) 928-77-51,
			    <BR>E-mail: <a href="mailto:do\@zanas.ru">do\@zanas.ru</a>
                    	    <DIV><IMG height=1 alt="" src="/i/images/1.gif" width=220><BR></DIV>
			</TD></TR>
					</TBODY>
				  </TABLE>
				</TD></TR>
			  </TBODY>
			</TABLE>
            <DIV></DIV>
            <DIV></DIV></TD></TR>
		</TBODY>
	  </TABLE>
      </DIV></DIV>
	</TR>
</TBODY>
</TABLE>
</BODY>
</HTML>
EOH
	
}

1;
