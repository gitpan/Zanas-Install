################################################################################

sub draw_item_of_images {

	my ($data) = @_;
	
	$_REQUEST {__no_navigation} = !$_REQUEST {list};

	my $esc =
		$_REQUEST {list} ? {type => 'articles', id => $data -> {id_article}} :
	        {id_doc => $data -> {id_article}, id => ''};
	
	draw_form ({

			esc => $esc,
			
			keep_params => ['list'],

			bottom_toolbar => draw_ok_esc_toolbar ({
				esc => $esc,
			})
			
		}, $data,
		[
			{
				name  => 'label',
				label => '���������',
			},
			{
				name  => 'photo',
				label => '����',
				type  => 'file',
			},
			{
				name  => 'ord',
				label => '������� ������',
				size  => 4,
			},
			[
				{
					name  => 'width',
					label => '������',
					size  => 4,
				},
				{
					name  => 'height',
					label => '������',
					size  => 4,
				},
			],
			[
				{
					name   => 'align',
					label  => '������������',
					type   => 'select',
					empty  => '',
					values => [
						{id => 'left', label => '�����'},
						{id => 'right', label => '������'},
						{id => 'center', label => '�� ������'},
					]
				},
				{
					name  => 'border',
					label => '�����',
					size  => 4,
				},
			],
			[
				{
					name  => 'hspace',
					label => '������ �� �����������',
					size  => 4,
				},
				{
					name  => 'vspace',
					label => '������ �� ���������',
					size  => 4,
				},
			],
		]
	)

	.

	($$data{path_photo} ? <<EOH : '')
		<table width=100% cellspacing=0 cellpadding=0><tr><td class=bgr4>

			<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Nulla vel metus. Fusce nunc quam, ultrices vel, scelerisque non, dictum ac, wisi. In a est non ante semper dictum. Quisque mi nunc, tempus sit amet, feugiat viverra, ornare vel, risus. Donec nec ligula. Morbi pharetra. Suspendisse massa turpis, lacinia id, adipiscing non, accumsan nec, mi. Donec vulputate. Fusce enim enim, rhoncus at, adipiscing at, sodales ut, lectus. Donec venenatis. Proin quis tellus ac arcu consequat adipiscing. Phasellus ullamcorper felis et arcu. Maecenas nonummy massa at nunc. Cras eu augue at urna viverra facilisis. Duis tortor urna, congue vitae, tincidunt at, mattis ac, diam. Quisque augue purus, blandit vitae, facilisis ut, molestie ut, odio. Pellentesque justo magna, faucibus nec, dictum et, tincidunt vitae, purus.

			<p>Nulla libero. Praesent non elit sed quam faucibus tempor. Integer urna. Sed leo ipsum, euismod ac, tincidunt vitae, fringilla eu, enim. In scelerisque. In condimentum, augue nec vestibulum mattis, massa sem convallis eros, imperdiet vehicula lectus nulla id nulla. Etiam laoreet egestas wisi. Integer tincidunt augue quis elit. Sed pede. Praesent elit orci, viverra ac, facilisis quis, viverra sit amet, nibh. Suspendisse in dui. In ultricies, purus eget aliquet suscipit, lacus augue varius metus, eu fermentum urna sem vestibulum nisl. Maecenas quis leo in sapien ultrices dictum. Aliquam elit neque, sagittis id, mollis ac, vehicula nec, ipsum. Pellentesque pretium accumsan libero. Duis elementum ultrices odio. Vivamus congue ornare ante. Pellentesque quis purus id erat lobortis lobortis. Pellentesque gravida.
			
			<img src="$$data{path_photo}" border=$$data{border} hspace=$$data{hspace} vspace=$$data{vspace} width=$$data{width} height=$$data{height} align=$$data{align}>

			<p>Curabitur pharetra sagittis est. Nullam ipsum sapien, consectetuer sed, consectetuer eu, venenatis vitae, wisi. Nulla facilisi. Suspendisse metus. Vivamus vel nisl. Mauris rhoncus dignissim quam. Integer a metus. Suspendisse sodales, enim pellentesque dignissim ultrices, diam wisi sagittis justo, quis vestibulum eros orci a dolor. Sed orci ante, cursus ultrices, ullamcorper vitae, varius ac, libero. In pharetra, mauris in accumsan gravida, augue sem tempus justo, posuere rhoncus nulla ipsum quis lorem. Sed metus velit, vestibulum ac, ultricies ac, posuere a, velit. Proin cursus diam eu elit. Maecenas pharetra aliquam purus.

			<p>Integer convallis felis sed ante varius laoreet. Ut pulvinar imperdiet elit. Sed adipiscing, ipsum volutpat hendrerit nonummy, purus nibh congue tellus, non pharetra pede dui eu nibh. Integer arcu tortor, semper imperdiet, accumsan porttitor, lobortis quis, enim. Morbi tempus. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Mauris quis nibh. Donec nec lorem. Donec in massa in ligula dapibus hendrerit. Phasellus scelerisque, est vitae tincidunt interdum, ipsum arcu convallis ligula, in auctor lacus augue sed magna. Integer nulla. Nunc eu nulla. Duis nibh. Praesent ligula. Nullam sodales mauris in nunc. Phasellus vitae leo eget enim sodales faucibus.
			
		</table>
EOH
	
	
}

################################################################################

sub draw_images {

	my ($data) = @_;
	
	$_REQUEST {__no_navigation} = 1;
	
	draw_table (
		
		['���������', '', ''],
	
		sub {
			
			draw_text_cells ({
				href  => "/?type=images&id=$$i{id}",
			}, [
				$i -> {label},
			])
			
			.

			draw_row_buttons ({},
				[
					{	
						icon => 'ok',
						label => '��������',
						href => "javaScript:opener.insertImageInDocExt('$$i{path_photo}', $$i{width}, $$i{height}, $$i{border}, $$i{vspace}, $$i{hspace}, '$$i{align}'); self.focus(); self.close ()",
					},
					{	
						icon => 'delete',
						label => '�������',
						href => "/?type=images&action=delete&id=$$i{id}",
						confirm => "������� �������� $$i{label}?"
					},
				]
			)
		},
			
		$data -> {images},
		
		{
			title => {label => '����� �����������'},
			top_toolbar => [
				{},
				{
					type  => 'button',
					label => '&��������',
					href  => {action => 'create'},
				},
			],
			toolbar => draw_close_toolbar,
			
		}
			
	)
	
	.
	
	js_ok_escape
	
	;
	
}

1;
