################################################################################

sub draw_item_of_articles {

	my ($data) = @_;
	
	my $toggle_label = $data -> {is_visible} ? '������' : '������������';

	draw_form ({
			
			esc => $data -> {parent} ?
				{id => $data -> {parent}} :
			        {id => '', parent => $data -> {id_rubric}, type => 'rubrics'},
			
			additional_buttons => [{
				label => $toggle_label,
				href  => {action => 'toggle'},
				confirm => "$toggle_label �������� '$$data{label}'?",
				off => $data -> {fake},
			}],
			
		}, $data,
		[
			{
				name  => 'label',
				label => '��������',
				size  => 60,
				max_len  => 255,
			},
#			[
				{
					name  => 'name',
					label => '������������� ���',
					size  => 30,
					off   => $data -> {full_path} =~ m{/forum/},
				},
				{
					name  => 'full_path',
					label => '����',
					type  => 'static',
				},
#			],
			{
				name  => 'ord',
				label => '������� ������',
				size  => 4,
				off    => ($data -> {rubric_path} =~ m{^/news} || $data -> {rubric_path} =~ m{^/guestbook} || $data -> {rubric_path} =~ m{^/forum}),
			},
			{
				name   => 'dt',
				label  => '����',
				type   => 'datetime',
#				no_time => 1,
				off    => ($data -> {rubric_path} !~ m{^/news} && $data -> {rubric_path} !~ m{^/guestbook} && $data -> {rubric_path} !~ m{^/forum}),
			},			
			{
				name   => 'announce',
				label  => '�����',
				type   => 'text',
				rows   => 3,
				cols   => 60,
				off    => ($data -> {rubric_path} =~ m{^/products} || $data -> {rubric_path} =~ m{^/guestbook} || $data -> {rubric_path} =~ m{^/forum} || $data -> {rubric_path} =~ m{^/jobs}),
			},
			{
				name   => 'body',
				label  => '�����',
				type   => 'htmleditor',
				rows   => 3,
				cols   => 60,
				off    => ($data -> {rubric_path} =~ m{^/(products|jobs)}),
			},			
		]
	)

	.
	
	draw_table (
		
		['', '�/�', '���������', ''],
	
		sub {
					
			qq{<td class=bgr0 width='1%' align=center><img src="$$i{path_photo}" border=1 height=30>}
				
			.

			draw_text_cells ({
				href  => "/?type=images&id=$$i{id}&list=1",
			}, [
			
				$i -> {ord} || '',
				$i -> {label},
			])
			
			.

			draw_row_buttons ({},
				[
					{	
						icon => 'delete',
						label => '�������',
						href => "/?type=images&action=delete&id=$$i{id}&list=1",
						confirm => "������� �������� $$i{label}?"
					},
				]
			)
		},
			
		$data -> {images},
		
		{
			title => {label => '��������'},

			name => 'form1',

			top_toolbar => [
				{},
				{
					type  => 'button',
					label => '&��������',
					href  => {action => 'create', type => 'images', list => 1, id_doc => $data -> {id}},
				},
			],
			
		}
			
	)
		
}

1;
