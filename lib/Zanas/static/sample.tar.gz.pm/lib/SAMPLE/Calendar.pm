package SAMPLE::Calendar;

################################################################################################

sub new {

	my ($class, $period, $granularity) = @_;
	
	my $self = {};
	
	bless $self, $class;
	
	return $self;

}


################################################################################

sub draw {

	my ($sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst) = localtime (time);
	
	$year += 1900;
	
	return <<EOH;

	<script language="JavaScript">

		<!--

		// borrowed from http://www.javascript-page.com

		var clockID = 0;
		var clockSeparators = new Array (' ', ':');
		var clockSeparatorID = 0;

		function UpdateClock() {

		   if (clockID) {
		      clearTimeout (clockID);
		      clockID = 0;
		   }

		   var tDate = new Date ();

		   document.getElementById ('clock_hours').innerText = twoDigits (tDate.getHours ());
		   document.getElementById ('clock_minutes').innerText = twoDigits (tDate.getMinutes ());
		   document.getElementById ('clock_separator').innerText = clockSeparators [clockSeparatorID];

		   clockSeparatorID = 1 - clockSeparatorID;

		   clockID = setTimeout("UpdateClock ()", 500);

		}

		function twoDigits (n) {
		   if (n > 9) return n;
		   return '0' + n;
		}

		function StartClock() {
		   clockID = setTimeout("UpdateClock ()", 0);
		}

		function KillClock() {
			if (!clockID) return;
			clearTimeout(clockID);
			clockID  = 0;
		}

		//-->

	</script>

	<body onload="StartClock()" onunload="KillClock()">	
	<nobr>�������: $mday $SAMPLE::month_names[$mon] $year&nbsp;&nbsp;&nbsp;<span id="clock_hours"></span><span id="clock_separator" style="width:5px"></span><span id="clock_minutes"></span></nobr>
	
EOH
	
}

1;