package SAMPLE;

use SAMPLE::Config;
use SAMPLE::Calendar;

use Zanas;

1;