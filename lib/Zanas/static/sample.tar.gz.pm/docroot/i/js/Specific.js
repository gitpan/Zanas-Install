function doHideUnhideNextSibling(ofWhat)
{
  var TN;
  TN = event.srcElement.tagName; 
  if (TN=='DIV' || TN=='SPAN' || TN=='TD') 
    if (ofWhat.nextSibling.id!='DontHide') 
      ofWhat.nextSibling.style.display = (ofWhat.nextSibling.style.display=='none' ? 'inline-block':'none')
}

function Menu_OnClick()
{
  if (this.Info!='')
  {
    document.all[this.Menu.Info[0]].value     = this.Info[0];
    document.all[this.Menu.Info[1]].innerHTML = this.Info[1];
    this.Menu.Layer.Items[0].Layer.Hide();
  }
}
