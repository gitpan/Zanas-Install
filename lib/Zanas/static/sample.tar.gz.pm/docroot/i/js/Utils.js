var 
  doc = document.all,
  Debug = false,
  DebugOutput = '',
  isDebugOutputDone = false;

function DoNothing() {}

function Dbg(Text)
{
  if (!Debug) return;
  DebugOutput = EscapeHTML(Text)+'<br>'+DebugOutput;
  if (isDebugOutputDone)
    doc['DebugOutput'].innerHTML = DebugOutput;
}

function renderDbg()
{
  if (!Debug) return;
  document.write('<br><hr><div style="font-family: Courier; font-size: 12px;">');
  document.write('&nbsp;&nbsp;<b>JavaScript Debug output:</b>');
  document.write('<div id="DebugOutput">'+DebugOutput+'</div></div>');
  isDebugOutputDone = true;
}

function EscapeJString(S)
{
  var ChFrom = ['\\\\','"'];
  var ChTo   = ['\\\\','\\"'];
  var i, re;
  for (i = 0; i<ChFrom.length; i++)
  {
    re = new RegExp('['+ChFrom[i]+']','gi');
    S = S.replace(re,ChTo[i]);
  }
  return S;
}

function EscapeHTML(S)
{
  var ChFrom = ['&','<','>','"',"'"];
  var ChTo   = ['&amp;','&lt;', '&gt;','&quot;','&apos;'];
  var i, re;
  for (i = 0; i<ChFrom.length; i++)
  {
    re = new RegExp('['+ChFrom[i]+']','gi');
    S = S.replace(re,ChTo[i]);
  }
  return S;
}

function UnEscapeHTML(S)
{
  var ChFrom = ['&amp;','&lt;', '&gt;','&quot;','&apos;'];
  var ChTo   = ['&','<','>','"',"'"];
  var i, re;
  for (i = 0; i<ChFrom.length; i++)
  {
    re = new RegExp(ChFrom[i],'gi');
    S = S.replace(re,ChTo[i]);
  }
  return S;
}

function DecryptStr(s,m)
{
  var o,i,j;

  o = '';
  if (m==null) m = 1;
  m = new Number(m);
  for (i = 0; i<s.length; i++) {
    j = s.charCodeAt(i)-m;
    if (j>=32 && j<128)
      o += String.fromCharCode(j);
    else
      o += String.fromCharCode(j+m);
  }
  return o;
}

function MakeEvent(Evt)
{
  if (Evt==null)
    return DoNothing;
  else if (typeof(Evt)=='string')
    return new Function(Evt);
  else if (typeof(Evt)!='function')
  {
    alert('MakeEvent: Bad event handler !!!');
    return DoNothing;
  }
  return Evt;
}

function Array2AssocArray(A, Def)
{
  var i = 0, j = 0, k = 0, NP, V, D, l;
  var O = new Array();
  var OD = new Array();
  
  if (Def[Def.length-Def.length%2]==null)
    Def[Def.length-Def.length%2] = 'Other';

  for (k = 0; k<Def.length - Def.length%2; k+=2)
  {
    V = Def[k];
    if (V.substr(0,1)=='!')
    {
      V = V.substr(1);
      Def[k] = V;
      OD[V] = true;
    }
    else
      OD[V] = false;
    O[V] = Def[k+1];
  }

  var L = A.length;
  while(i<L)
  {
    V = A[i];
    if (typeof(V)=='string')
    {
      if (OD[V]!=null)
      {
        NP = true;
        D = A[i+1];
        i+=2;
      }
      else
      {
        NP = false;
        if (V.substr(0,1)=='=')
          D = V.substr(1);
        else
          D = V;
        i+=1;
      }
    }
    else
    {
      NP = false;
      D = V;
      i+=1;
    };

    if (NP)
    {
      O[V] = D;
      OD[V] = true;
    }
    else
    {
      while (OD[Def[j]] && Def[j+2]!=null)
        j+=2;
      V = Def[j];
      if (Def[j+2]==null) 
      {
        if (typeof(O[V])=='object')
        {
          l = O[V].length;
          if (l!=null)
            O[V][l] = D;
          else
            O[V] = [D];
        }
        else
          O[V] = [D];
      }
      else
      {
        if (typeof(D)!='undefined')
          O[V] = D;
        OD[V] = true;
        j+=2;
      }
    }
  }
  return O;
}
