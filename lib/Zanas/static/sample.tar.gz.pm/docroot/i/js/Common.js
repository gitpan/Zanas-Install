var
  eventsBound = false,
  LastUsedControl = null,
  hBlockingInterval = null,
  isDOM = null,
  isMSIE = null,
  isNetscape4 = null,
  isOpera = null,
  isOpera5 = null,
  isOpera6 = null,
  isNC = null,
  isNC4 = null,
  isNC6 = null,
  isMSIE5 = null,
  isMozilla = null,
  isKonqueror = null,
  isNetscape6 = null;


function DetectBrowser()
{
  isDOM=(document.getElementById)?true:false; //DOM1 browser (MSIE 5+, Netscape 6, Opera 5+)
  isOpera=(window.opera)?true:false;
  isOpera5=isOpera && isDOM;    //Opera 5+
  isOpera6=(isOpera5 && window.print)?true:false;   //Opera 6+
  isMSIE=isIE=(document.all && document.all.item && !isOpera)?true:false;  //Microsoft Internet Explorer 4+
  isMSIE5=isDOM && isMSIE; //MSIE 5+
  isNC4=(document.layers)?true:false;
  isNC6=isMozilla=isDOM && navigator.appName=="Netscape";
  isNC=isNC4 || isNC6;
  isKonqueror=(navigator.userAgent.indexOf("Konqueror")>-1)?true:false;
  if (isMozilla) {
//   alert(navigator.userAgent.substr(navigator.userAgent.indexOf("Gecko/")+6,8));
   isGeckoBug=isMozilla && (navigator.userAgent.substr(navigator.userAgent.indexOf("Gecko/")+6,8)<"20011120");
//   if (isGeckoBug) {alert("Bug found")}
  }
}
  
function GlobalOnLoad()
{
  if (eventsBound) return true;

  eventsBound = true;
  DetectBrowser();

  var fm = document.forms["MainForm"]; 
  //document.getElementById("MainForm");  

  if (isMozilla || isKonqueror) {
    fm.onclick=function(e)
    {
      if (hBlockingInterval==null)
        LastUsedControl = e.target;
      return true;
    };

    fm.onkeypress=function(e)
    {
      LastUsedControl = e.target;
      GlobalOnBlockingInterval();
      hBlockingInterval = setInterval("GlobalOnBlockingInterval()", 0);
      return true;
    };
  }
  else if (isMSIE) {
    fm.onclick=function()
    {
      if (hBlockingInterval==null)
        LastUsedControl = event.srcElement;
      return true;
    };

    fm.onkeypress=function()
    {
      LastUsedControl = event.srcElement;
      GlobalOnBlockingInterval();
      hBlockingInterval = setInterval("GlobalOnBlockingInterval()", 0);
      return true;
    };
  }
  else if (isOpera5) {
    fm.onclick=function()
    {
      if (hBlockingInterval==null)
        LastUsedControl = event.target;
      return true;
    };

    fm.onkeypress=function()
    {
      LastUsedControl = event.target;
      GlobalOnBlockingInterval();
      hBlockingInterval = setInterval("GlobalOnBlockingInterval()", 0);
      return true;
    };
  }
}

function GlobalOnBlockingInterval()
{
  if (hBlockingInterval!=null)
  {
    clearInterval(hBlockingInterval);
    hBlockingInterval = null;
  }
}

function FindLastUsedLogicalForm()
{
  if (LastUsedControl==null) 
    return;
  if (isDOM) {
    var p = LastUsedControl.parentNode;
  }
  else if (isMSIE) {
    var p = LastUsedControl.parentElement;
  }
  while(true)
  {
    if (p==null) return null;
    if (p.id!=null)
      if (p.id.substr(0,12)=='LogicalForm_') {
//      alert(p.id);
        return p;
      }
   if (isDOM) {
     p = p.parentNode;
   }
   else if (isMSIE) {
     p = p.parentElement;
   }
    
  }
}

function GlobalOnSubmit()
{
  function SetFirstHidden(LFs, LFC) {
   var LF, i, j;
    if (LFs==null) return;
    if (LFs.length==null) return;
//    alert (LFs.length);
    for (i = 0; i<=LFs.length; i++) {
//    alert ("in cycle by LFs: step " + i);
     if (i<LFs.length) {
      LF = LFs[i];
     } else if (LFC!=null) {
      LF = LFC;
     } else break;

     if (LF.id.substr(0,12)=='LogicalForm_') {
      FirstHidden = null;
      if (isDOM) {
        SubElements = LF.getElementsByTagName("input");
        FirstHidden = SubElements[0];
      }
      else if (isMSIE) {
        SubElements = LF.children;                       //IE only
        for (j = 0; j<SubElements.length; j++)
          if (SubElements[j].tagName=='INPUT')
          {
            FirstHidden = SubElements[j];
            break;
          }
      }
      if (FirstHidden==null) {
        alert('Bad LogicalForm definition !!!');
        event.returnValue = false;
        return;
      }
      if (FirstHidden.type!='hidden') {
        alert('Bad LogicalForm definition !!!');
        event.returnValue = false;
        return;
      }
      FirstHidden.value = (i<LFs.length)?0:1;
     }
    }
  }

  function RenameLFs(LFs, LFC) {
      if (LFC!=null) {
      if (LFs.length==null) return;
      for (i = 0; i<LFs.length; i++)
      {
        if (LFs[i].id!=LFC.id) continue;
        if (LFs[i]==LFC) continue;
        if (isMozilla) {
         SubElements = LFs[i].childNodes;
        } else if (isMSIE) {
         SubElements = LFs[i].all;
        } else if (isOpera6) {
         SubElements = LFs[i].children;
        }
        for (j = 0; j<SubElements.length; j++)
          if (SubElements[j].tagName=='INPUT' || SubElements[j].tagName=='TEXTAREA')
            SubElements[j].name = 'tmp2212_'+SubElements[j].name;
      }
    }
  }

  var i, j, Obj, Src, LFC, LFs1, LFs2, SubElements, FirstHidden;

  GlobalOnBlockingInterval();
  LFC = FindLastUsedLogicalForm();               

  if (isDOM) {
   LFs1 = document.getElementsByTagName("div");        //works in all DOM
   LFs2 = document.getElementsByTagName("span");
  } else if (isMSIE) {
   LFs1 = document.all.tags("div");
   LFs2 = document.all.tags("span");
  } 

  SetFirstHidden(LFs1, LFC);
  SetFirstHidden(LFs2, LFC);

  // Let`s cleanup other logical forms with same IDs
  if (isMSIE || isMozilla || isOpera6) {
   RenameLFs(LFs1, LFC);
   RenameLFs(LFs2, LFC);
  }


  if (isMSIE) {
    if (typeof(XCWEDefaults)!='undefined')
      for (i in XCWebEdits)
        XCWebEdits[i].saveText();
  }
}
